<?php
    define ('SESSION_TIMEOUT', 10); // sessions validity in seconds
    define ('USERNAME', 'webap2');
    define ('PASSWORD', 'ltesch');
    define ('LOGIN_DELAY', 0); // login delay in seconds
    define('OPENWEATHERMAP_API', '3f35e6fa452e618da9ae62aa6f275aa5');
    define('OPENWEATHERMAP_DELAY', 600); // delay for openweathermap in seconds
?>
