<?php

    require('inc/params.inc.php');

    function updateWeather($filename) {
        $url = sprintf("http://api.openweathermap.org/data/2.5/weather?q=Luxembourg&units=metric&APPID=%s", OPENWEATHERMAP_API);
        $weather = file_get_contents($url);
        $weather = json_decode($weather);

        $content = array();
        $content['temp'] =  $weather->main->temp;
        $content['pressure'] =  $weather->main->pressure;
        $content['humidity'] =  $weather->main->humidity;
        $content['wind_speed'] =  $weather->wind->speed;
        $content['wind_deg'] =  $weather->wind->deg;

        file_put_contents($filename, json_encode($content));
    }

    header('Content-Type: application/json');
    $output = array();

    // check if an API key has been provided
    if (isset($_GET['key'])) {

        // use the API key as session id
        session_id($_GET['key']);

        // start the session with the provided key
        session_start();

        // check if the provided key starts a session that is still active
        if (!isset($_SESSION['LOGIN_TIME'])) {
            $output['error'] = "Invalid key.";
        } else if (time() - $_SESSION['LOGIN_TIME'] > SESSION_TIMEOUT) {
            $output['error'] = "Key expired.";
            session_unset();     // unset $_SESSION variable for the run-time
            session_destroy();   // destroy session data in storage
        } else {
            // key is still ok
                $filename = 'weather.txt';

                if (!file_exists($filename)) {
                    touch($filename);
                    updateWeather($filename);
                }

                if (time() - filemtime($filename) >= OPENWEATHERMAP_DELAY) {
                    updateWeather($filename);
                }

                $output = json_decode(file_get_contents($filename));
        }
    } else {
        $output['error'] = "Invalid credentials. Log in first.";
    }


    echo json_encode($output);
?>
