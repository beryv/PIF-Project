<?php

    require('inc/params.inc.php');

    header('Content-Type: application/json');
    $output = array();

    // check login
    if (isset($_GET['username']) && isset($_GET['password'])) {
        sleep(LOGIN_DELAY);
        $username = $_GET['username'];
        $password = $_GET['password'];

        if ($username === USERNAME && $password === PASSWORD) {
            session_start();
            session_regenerate_id();
            $_SESSION['LOGIN_TIME'] = time();
            $output['key'] = session_id();
            $output['validity'] = SESSION_TIMEOUT;
                
            /*
            if (!isset($_SESSION['LOGIN_TIME'])) {
                $_SESSION['LOGIN_TIME'] = time();
                $output['key'] = session_id();
                $output['validity'] = SESSION_TIMEOUT;
            } else if (time() - $_SESSION['LOGIN_TIME'] < SESSION_TIMEOUT) {
                $output['key'] = session_id();
                $output['validity'] = SESSION_TIMEOUT - (time() - $_SESSION['LOGIN_TIME']);
            } else {
                session_regenerate_id();
                $_SESSION['LOGIN_TIME'] = time();
                $output['key'] = session_id();
                $output['validity'] = SESSION_TIMEOUT;
            }
            */
        } else {
            $output['error'] = 'Invalid username or password';
        }
    } else {
        $output['error'] = 'Missing username or password';
    }

    echo json_encode($output);
?>
